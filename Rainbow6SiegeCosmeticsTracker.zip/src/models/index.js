// Exports the models to be used by the controllers
module.exports.Account = require('./Account.js');
module.exports.Weapon = require('./Weapon.js');
module.exports.Charm = require('./Charm.js');
module.exports.Headgear = require('./Headgear.js');
module.exports.Uniform = require('./Uniform.js');
